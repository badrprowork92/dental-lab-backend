import { useMemo, useState } from "react";

import { formatMoney } from "@/lib/lab-format";
import { trpc } from "@/lib/trpc";
import { SelectField, SelectionSheet } from "./lab-ui";

type CurrencyCode = "YER" | "SAR" | "USD";

export function CashboxField({ value, onChange, currencyCode, label = "الصندوق" }: { value: number | null; onChange: (value: number) => void; currencyCode?: CurrencyCode; label?: string }) {
  const [open, setOpen] = useState(false);
  const { data: cashboxes = [] } = trpc.lab.cashboxes.list.useQuery();
  const options = useMemo(() => cashboxes.filter((item) => item.isActive && (!currencyCode || item.currencyCode === currencyCode)), [cashboxes, currencyCode]);
  const selected = options.find((item) => item.id === value);
  return <>
    <SelectField label={`${label} (إجباري)`} value={selected ? `${selected.cashboxName} · ${selected.currencyCode} · ${formatMoney(selected.currentBalance)}` : undefined} placeholder={options.length ? "اختر الصندوق" : "أضف صندوقًا ماليًا أولًا"} onPress={() => setOpen(true)} />
    <SelectionSheet visible={open} title="اختر الصندوق المالي" items={options.map((item) => ({ id: item.id, label: item.cashboxName, subtitle: `${item.currencyCode} · الرصيد: ${formatMoney(item.currentBalance)}` }))} onClose={() => setOpen(false)} onSelect={(item) => { onChange(item.id); setOpen(false); }} />
  </>;
}
